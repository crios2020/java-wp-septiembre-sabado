import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Clase05 {

	public static void main(String[] args) {
		System.out.println("Hola Mundo!");
		System.out.println("Versión de Java: "+System.getProperty("java.version"));
		//System.out.println(10/0);
		//System.out.println("Esta sentencia no se ejecuta!!!!!");

		/*
		 * 			Manejo de Exceptions
		 * 
		 * 			Estructura try - catch - finally
		 * 
		 * 	try{											//Obligatorio
		 * 		- Colocar aquí las sentencias que pueden arrojar una exception.
		 * 		- Estas sentencias tienen más costo de hardware.
		 * 		- Si se puede ejecutar sin exception el bloque termina normalmente.
		 * 		- Si ocurre una exception, se corta la ejecución de este bloque 
		 * 			y pasa el control del programa al bloque catch.
		 * 	} catch (Exception e) { 						//Obligatorio
		 * 		- Este bloque se ejecuta en caso de exception.
		 * 		- Se recibe como parámetro un objeto de exception.
		 * 	} finally {										//Opcional
		 * 		- Este bloque se ejecuta siémpre, ocurra exception o no.
		 * 		- Las variables declaradas en bloque try o catch estan fuera de scope (alcance).
		 *  }
		 *  - El programa termina normalmente
		 * 	- FIN DEL PROGRAMA
		 * 
		 */

		// try {
		// 	System.out.println(10/0);
		// 	System.out.println("Esta sentencia no se ejecuta!");
		// } catch (Exception e) {
		// 	System.out.println("Ocurrio un error!!");
		// 	System.out.println(e);
		// } finally {
		// 	System.out.println("El programa termina normalmente!");
		// }

		try {
			//GeneradorException.generar();
			//GeneradorException.generar(true);
			//GeneradorException.generar("38v");
			//GeneradorException.generar(null, 2);
			//GeneradorException.generar("hola",23);
		} catch (Exception e) {
			System.out.println(e);
		}

		//Checked - Unchecked Exception

		//Unchecked Exception: extienden de RuntimeException, no tenemos la obligación de controlarlas.
		//Checked Excpetion: no extienden de RuntimeException, tenemos la obligación de controlarlas.

		//GeneradorException.generar();
		// try {
		// 	FileReader in=new FileReader("texto.txt");
		// } catch (FileNotFoundException e) {
		// 	System.out.println(e);
		// }
		// System.out.println("Fin del programa!");


		//Captura personalizada de Exceptions
		try {
			//GeneradorException.generar();
			//GeneradorException.generar(true);
			//GeneradorException.generar("26l");
			//GeneradorException.generar(null,23);
			//GeneradorException.generar("hola", 65);
			FileReader in=new FileReader("texto.txt");
		} catch (ArithmeticException e) 			{ System.out.println("División / 0");
		//} catch (ArrayIndexOutOfBoundsException e) 	{ System.out.println("Indice fuera de rango!");
		} catch (NumberFormatException e) 			{ System.out.println("Formato de número incorrecto!");
		} catch (NullPointerException e) 			{ System.out.println("Puntero Nul!");
		//} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice fuera de rango!");
		//} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) 	{ System.out.println("Indice fuera de rango!");
		} catch (IndexOutOfBoundsException e)		{ System.out.println("Indice fuera de rango!");
		} catch (FileNotFoundException e) 			{ System.out.println("Archico no encontrado!");
		} catch (IOException e)						{ System.out.println("Error I/O!");
	 	} catch (Exception e) 						{ System.out.println("Ocurrio un error no esperado!"); }


		//Uso de Exception para validar reglas de negocio
		Vuelo vuelo1=new Vuelo("AER1234",100);
		Vuelo vuelo2=new Vuelo("LAT1111",100);

		try{
			// vuelo1.venderPasajes(50);
			// vuelo2.venderPasajes(20);
			// vuelo1.venderPasajes(40);
			// vuelo2.venderPasajes(30);
			// vuelo1.venderPasajes(30); 		//Lanza una Exception
			// vuelo2.venderPasajes(10); 		//Esta venta no se realiza			
		}catch(Exception e){
			System.out.println(e);
		}

		try{
			//funcion3();
		}catch(Exception e){
			System.out.println("Ocurrio un error!");
		}

		//funcion4();

		//System.out.println("Fin del programa!!");



		//NO HACER ESTO!!!!!!!!!
		// Lector lector=null;
		// try {
		// 	lector=new Lector("texto.txt");
		// 	System.out.println(lector.leer());
		// 	lector.close();
		// } catch (Exception e) {
		// 	System.out.println();
		// } finally {
		// 	try{
		// 		if(lector!=null){
		// 			lector.close();
		// 		}
		// 	}catch(Exception e){
		// 		System.out.println(e);
		// 	}
		// }

		//Try with resources		JDK 7 o sup
		try (Lector lector=new Lector("texto.txt")){
			System.out.println(lector.leer());
		} catch (Exception e) {
			System.out.println(e);
		}











	}

	public static void funcion1() throws Exception{
		throw new Exception();
	}

	public static void funcion2() throws Exception{
		funcion1();
	}

	public static void funcion3() throws Exception{
		funcion2();
	}

	public static void funcion4(){
		try{
			funcion3();
		}catch(Exception e){
			System.out.println("Ocurrio un error!");
		}
	}
}
