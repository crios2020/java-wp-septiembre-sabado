import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lector implements AutoCloseable{
    private FileReader lector;

    public Lector(String file) throws FileNotFoundException{
        lector=new FileReader("texto.txt");
    }

    public int leer() throws IOException{
        return lector.read();
    }

    @Override
    public void close() throws Exception {
        lector.close();
        System.out.println("Se cerro el archivo!");
    }

}
