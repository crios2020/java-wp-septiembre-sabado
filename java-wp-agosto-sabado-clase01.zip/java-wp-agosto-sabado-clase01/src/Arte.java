
public class Arte {
	public static void main(String[] args) {
		// """ a partir de JDK 16 o sup
		// https://fsymbols.com/es/arte-de-texto/
		System.out.println(ColoresANSI.ANSI_GREEN);
		System.out.println("""
				∵*.•´¸.•*´✶´♡
				° ☆ °˛*˛☆_Π______*˚☆*
				˚ ˛★˛•˚*/______/ ~⧹。˚˚
				˚ ˛•˛•˚ ｜ 田田 ｜門｜ ˚*
				🌷╬╬🌷╬╬🌷╬╬🌷╬╬🌷
		""");
		System.out.println(ColoresANSI.ANSI_RESET);
	}
}
