import java.math.BigDecimal;
import java.math.BigInteger;

import javax.swing.JOptionPane;

/**
 * Clase principal del proyecto primer clase del curso
 * @author carlos
 *
 */
public class Clase01 {

	/**
	 * Punto de entrada del proyecto
	 * @param args Argumentos que ingresan desde consola
	 */
	public static void main(String[] args) {
		
		/*
		 * Curso: 	Java Standard Web Programming	40 hs.
		 * Días:	Sábado	10:00 a 13:00 hs.
		 * Profe:	Carlos Rios		carlos.rios@educacionit.com
		 * Materiales:		alumni.educacionit.com
		 * 				user: email
		 * 				pass: dni
		 * Github:	https://github.com/crios2020/java-wp-agosto-sabado
		 * 
		 * Software:	JDK - LTS (Java Development Kit) - (Kit de Desarrollo Java)
		 * 				LTS Long Term Support	(8 años)
		 * 				Versión recomendada:	17 lts
		 * 	
		 * IDE:			IDE (Integrated Development Enviroment) - (Entorno de Desarrollo Integrado)
		 * 			Eclipse Java Web Developer - Spring Tools Suite (https://spring.io/tools) - VSCode - IntelliJ - Netbeans
		 * 
		 */
		
		//Comentario de una sola linea
		/* Bloque de comentarios */
		//TODO Tarea pendiente
		/**
		 * Comentario JavaDOC
		 * Colocar este comentario delante de la declaración de método o clase
		 * Este comentario puede ser visto desde fuera del archivo binario
		 */
		
		System.out.println("Hola Mundo!!");
		
		// f11 para ejecutar en eclipse
		// syso - ctrol space para System.out.println(); en eclipse
		// sout - tab para System.out.println(); en otros ides
		
		//Argumentos que ingresan por consola
		System.out.println("Longitud args: "+args.length);
		for(int a=0; a<args.length; a++) {
			System.out.println(args[a]);
		}
		
		//Organización del projecto
		//JOptionPane.showMessageDialog(null, "Hola Mundo!");
		
		//Lenguaje de tipado fuerte:	Java, C++, C# , Visual Basic
		//Lenguaje de tipado debil:		JavaScript, Python, PHP
		
		//Tipo de datos primitivos
		
		//Tipo de datos entero
		
		//Tipo de datos boolean			// 1 byte
		boolean bo=true;		// 1
		System.out.println(bo);
		bo=false;				// 0
		System.out.println(bo);
		
		/*
		 *  00000001
		 * 	--------
		 */
		
		//Tipo de datos byte			// 1 byte signed
		System.out.println(Math.pow(2, 8));
		byte by=-128;
		System.out.println(by);
		by=127;
		System.out.println(by);
		
		/*
		 * 		byte
		 * 		|--------|--------|
		 * 	  -128       0       127
		 * 
		 * 		byteU
		 * 		|-----------------|
		 * 		0				 255
		 */
		
		//Tipo de datos short			// 2 bytes signed
		System.out.println(Math.pow(2, 16));
		short sh=-32000;
		System.out.println(sh);
		sh=32000;
		System.out.println(sh);
		
		//Tipo de datos int				// 4 bytes signed
		System.out.println(Math.pow(2, 32));
		int in=-2000000000;
		System.out.println(in);
		in=2000000000;	
		System.out.println(in);
		
		//Tipo de datos long			// 8 bytes
		System.out.println(Math.pow(2, 64));
		long lo=3000000000L;
		System.out.println(lo);
		
		//Tipo de datos char unicode			// 2 bytes unsigned
		char ch=65;
		System.out.println(ch);
		ch+=32;
		System.out.println(ch);
		ch='&';
		System.out.println(ch);

		//int año=2022;
		int anio=2022;
		//System.out.println("Que lindo año!!");
		
		
		//Tipo de datos punto Flotante
		//Tipo de datos float 32 bits
		float fl=3.36f;
		System.out.println(fl);
		
		//Tipo de datos double 64 bits
		double dl=3.36;
		System.out.println(dl);
		
		fl=10;
		dl=10;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=100;
		dl=100;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=1000;
		dl=1000;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		for(double d = 10; d >= 0; d -= 0.1){
		     System.out.println("D vale: " + d);
		}
		
		//Clase BigDecimal
		//https://computandocodigo.wordpress.com/2019/03/07/bigdecimal-para-calculos-precisos-en-lugar-de-double-para-java/#:~:text=Para%20utilizarlo%20hay%20que%20construir,con%20el%20valor%20de%2012.5.
		//BigDecimal bg=new BigDecimal(10);
		//System.out.println(bg.divide(new BigDecimal(3)));
		BigDecimal bd = new BigDecimal(new BigInteger("0"));
//		for(int a=1; a<=100; a++) {
//			bd.add(new BigDecimal("0.1"));
//			System.out.println("valor: " + bd.doubleValue());
//		}
		
		//Clase String
		String st="hola";
		System.out.println(st);
		
		/*
		 * JDK 9 o inf
		 * 		String st="hola";			private final char[] value;				8 bytes
		 * 
		 * JDK 10 o sup
		 * 		String st="hola";			private final byte[] value;				4 bytes
		 * 
		 */
		
		//Clase Object no es primitivo
		Object o=3;
		o="Hola";
		o=true;
		
		
		
	}

}
