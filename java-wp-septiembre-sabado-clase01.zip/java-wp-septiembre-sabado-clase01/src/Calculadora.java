/**
 * Clase Calculadora, permite realizar operaciones básicas de la matematicas.
 * @author carlos
 *
 */
public class Calculadora {
	
	/**
	 * Suma dos números
	 * @param nro1	Termino 1
	 * @param nro2	Termino 2
	 * @return resultado de la suma
	 */
	public double sumar(float nro1, float nro2) {
		return nro1+nro2;
	}
	
	/**
	 * Resta dos números
	 * @param nro1	Termino 1
	 * @param nro2	Termino 2
	 * @return resultado de la resta
	 */
	public double restar(float nro1, float nro2) {
		//TODO realizar y retornar la resta de parámetros
		return 0;
	}
	
	/**
	 * Divide dos números
	 * @param nro1	Termino 1
	 * @param nro2	Termino 2
	 * @return resultado de la división
	 */
	public double dividir(float nro1, float nro2) {
		//TODO realizar y retornar la división de parámetros, contemplar la división por 0
		return 0;
	}
	
	/**
	 * Multiplica dos números
	 * @param nro1	Termino 1
	 * @param nro2	Termino 2
	 * @return resultado de la multiplicación
	 */
	public double multiplicar(float nro1, float nro2) {
		//TODO realizar y retornar la multiplicación de parámetros 
		return 0;
	}
}
