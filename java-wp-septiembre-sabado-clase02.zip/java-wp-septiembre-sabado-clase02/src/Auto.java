//Declaración de clase
public class Auto {
	
	//atributos
	String marca;
	String modelo;
	String color;
	int velocidad;
	
	//Método constructor
	
	/**
	 * Este método fue deprecado por Carlos Rios el 10/09/2022 por resultar inseguro
	 * usar en su reemplazo Auto(String marca, String modelo, String color)
	 */
	@Deprecated
	Auto(){} //Constructor vacio
	
	Auto(String marca, String modelo, String color){
		this.marca=marca;
		this.modelo=modelo;
		this.color=color;
	}
	
	//métodos
	void acelerar() {											//acelerar
		velocidad+=10;
		if(velocidad>100) velocidad=100;
	}
	
	//método sobrecargado
	void acelerar(int kilometros) {								//acelerarInt
		velocidad+=kilometros;
		if(velocidad>100) velocidad=100;
	}
	
	void acelerar(int kilometros, String ubicacion) {			//acelerarIntString
		
	}
	
	void frenar() {
		velocidad-=10;
	}
	
	//void no devuelve valor
	void imprimirVelocidad() {
		System.out.println(velocidad);
	}
	
	int obtenerVelocidad() {
		return velocidad;
	}
	
	String getEstado() {
		return  marca+", "+modelo+", "+color+", "+velocidad;
	}
	
	@Override
	public String toString() {
		return getEstado();
	}
	
}//end class
