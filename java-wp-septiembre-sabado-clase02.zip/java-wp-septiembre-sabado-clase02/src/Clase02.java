import javax.swing.JOptionPane;

public class Clase02 {

	public static void main(String[] args) {
		// Clase 02 Paradigma de Objetos
		// Nuevo Repositorio https://github.com/crios2020/java-wp-septiembre-sabado
		
		// https://www.adictosaltrabajo.com/2010/05/25/atajos-eclipse/
		
		System.out.println("Versión de Java: "+System.getProperty("java.version"));
		
		/*
		 * Paradigma de Objetos
		 * 
		 * Que es una clase? una clase representa algo generico o algo sustantivo 
		 * 		Ej: Vendedor, Cliente, Automovil, ElementoQuirurjico
		 * 
		 * Clases en Java: son objetos de la clase java.lang.Class
		 * 
		 * Que son los atributos? describen a la clase, son adjetivos de la clase.
		 * 		tienen un tipo de datos asociado, Las clases declaran los atributos
		 * 		y los objetos completan el estado (valor)
		 * 
		 * Atributos en java: son objetos de la clase java.lang.reflect.Field
		 * 
		 * Que son los objetos: son instancias de la clase, Representan situaciones
		 * 		en particulas, tienen estado propio (valor de los atributos)
		 * 
		 * Que son los métodos em java? son acciones que realiza la clase, se detectan
		 * 		como verbos.
		 * 		Opcionalmente puede tener parámetros de entrada y de salida
		 * 
		 * Métodos en java: son objetos de la clase java.lang.reflect.Method
		 * 
		 * Parámetros de entrada: Son valores entregados (ingresados) a un método,
		 * 	el método toma dichos valores y los usa como variables locales para
		 *  realizar cambios en el comportamiento.
		 *  
		 * Sobrecarga de métodos: Es cuando existen métodos llamados iguales 
		 * 	dentro de una clase, pero difieren en la firma de parámetros de
		 *  entrada (cantidad y o tipo de parámetros). 
		 * 
		 * Métodos constructores: Se utilizan para inicializar un objeto, se ejecutan
		 *  cuando se crea un objeto de la clase, y el constructor tiene el mismo nombre que la clase
		 *  los constructores se pueden sobrecargar.
		 *  Si una clase no tiene constructor, java agrega un constructor vacio en tiempo de
		 *  compilación.
		 */

		System.out.println("-- auto1 --");
		Auto auto1=new Auto();					//new Auto(); construir un objeto
		auto1.marca="Fiat";
		auto1.modelo="Toro";
		auto1.color="Verde";
		auto1.acelerar();			//10
		auto1.acelerar();			//20
		auto1.acelerar();			//30
		auto1.frenar();				//20
		auto1.acelerar(23);			//43
		auto1.acelerar(38);			//81
		
		//Imprimimos el estado de auto1
		System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
		
		System.out.println("-- auto2 --");
		Auto auto2=new Auto();
		auto2.marca="Ford";
		auto2.modelo="Ka";
		auto2.color="Negro";
		
		for(int a=0; a<=42; a++) auto2.acelerar();
		
		System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
		
		System.out.println("-- auto3 --");
		Auto auto3=new Auto("Citroen", "C4", "Bordo");
		auto3.acelerar(45);
		
		//auto3.imprimirVelocidad();
		//System.out.println(auto3.obtenerVelocidad());
		//JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.obtenerVelocidad());
		
		
		//método .toString()
		System.out.println(auto3.getEstado());
		System.out.println(auto3.toString());
		System.out.println(auto3);
		
		
		Auto auto4=new Auto();
		
		//Auto autox;
		//System.out.println(autox.marca);
		//int x;
		//System.out.println(x);	//Error la variable debe ser inicializada
		
		System.out.println("-- auto5 --");
		Auto auto5=new Auto("Fiat","Idea","Naranja");
		auto5.acelerar(56);
		System.out.println(auto5);
		
		
		//Clase Java Sábado
		Profesor profe=new Profesor();
		profe.nombre="Carlos";
		profe.apellido="Rios";
		
		Moderador moderadora=new Moderador();
		moderadora.nombre="Paula";
		moderadora.apellido="Aguilar";
		
		Alumno alumno1=new Alumno();
		alumno1.nombre="Nancy";
		alumno1.apellido="Bosich";
		
		Alumno alumno2=new Alumno();
		alumno2.nombre="Rodolfo";
		alumno2.apellido="Masip";
		
		profe.asistirAClases();
		moderadora.asistirAClases();
		alumno1.asistirAClases();
		alumno2.asistirAClases();
		
		//String dia="LUNS";
		Semana dia=Semana.SÁBADO;
		
		//TODO Encapsulamiento.
		//TODO Modificadores de Visibilidad.
		
	}

}
