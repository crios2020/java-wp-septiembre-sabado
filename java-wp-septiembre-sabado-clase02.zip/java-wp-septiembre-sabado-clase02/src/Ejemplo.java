
public class Ejemplo {

}

class Ejemplo2{}
class Ejemplo3{}

interface Interface1{}
interface Interface2{}

enum Enumerado1{}
enum Enumerado2{}

enum Semana{
	LUNES,
	MARTES,
	MIÉRCOLES,
	JUEVES,
	VIERNES,
	SÁBADO,
	DOMINGO
}

