
public class Empleado {
	
	int nroLegajo;
	String nombre;
	double sueldoBasico;
	//Cuenta cuenta; //Relaciones entre clases
	
	public Empleado(int nroLegajo, String nombre, double sueldoBasico) {
		this.nroLegajo = nroLegajo;
		this.nombre = nombre;
		this.sueldoBasico = sueldoBasico;
	}

	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico + "]";
	}

	public int getNroLegajo() {
		return nroLegajo;
	}

	public void setNroLegajo(int nroLegajo) {
		this.nroLegajo = nroLegajo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSueldoBasico() {
		return sueldoBasico;
	}

	public void setSueldoBasico(double sueldoBasico) {
		this.sueldoBasico = sueldoBasico;
	}

}
