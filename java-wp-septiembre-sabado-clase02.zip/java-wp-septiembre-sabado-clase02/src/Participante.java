
public class Participante {
	String nombre;
	String apellido;
	String rol;		//alumno, moderador, profesor
	
	void asistirAClases() {
		if(rol=="alumno") {
			//mira la clase
		}
		
		if(rol=="moderador") {
			//toma asistencia
		}
		
		if(rol=="profesor") {
			//dicta la clase
		}
	}
}

//Ejemplo de Herencia
class ParticipanteClase{
	String nombre;
	String apellido;
}

class Alumno extends ParticipanteClase{
	void asistirAClases() {
		//Mirar la clase
		System.out.println(nombre+" "+apellido+" estan en clases!");
	}
}

class Moderador extends ParticipanteClase{
	void asistirAClases() {
		//Toma la asistencia
		System.out.println(nombre+" "+apellido+" toma la asistencia!");
	}
}

class Profesor extends ParticipanteClase{
	void asistirAClases() {
		//Dicta la clase
		System.out.println(nombre+" "+apellido+" dicta la clase!");
	}
}
