package ar.com.eduit.curso.java.entities;

//Visibilidad de miembros de archivos
//Un solo miembro de archivo puede ser publico y 
//tiene que tener el mismo nombre que el archivo
//El miembro de archivo publico puede ser accedido desde cualquier paquete

//Los miembros de archivo no publicos, solo pueden ser accedidos desde el mismo paquete


public class Ejemplo {}
class Ejemplo2{}
class Ejemplo3{}

interface Interface1{}
interface Interface2{}

enum Enumerado1{}
enum Enumerado2{}


