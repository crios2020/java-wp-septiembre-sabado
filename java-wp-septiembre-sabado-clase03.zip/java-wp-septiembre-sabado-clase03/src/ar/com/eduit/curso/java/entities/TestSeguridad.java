package ar.com.eduit.curso.java.entities;

public class TestSeguridad {

	public static void main(String[] args) {
		//System.out.println("-- cuenta1 --");
		//Cuenta cuenta1=new Cuenta();
		//cuenta1.saldo=3000000;
	}

}
