package ar.com.eduit.curso.java.test;
import java.math.BigDecimal;
public class Test {

	public static void main(String[] args) {
		//Ensayo BigDecimal			Eliana
		BigDecimal x = new BigDecimal("3.0"); 
		BigDecimal y = new BigDecimal("5"); 
		BigDecimal z = x.add(y); 
		System.out.println("Sum of x+y = " + z); 
		//https://examples.javacodegeeks.com/java-bigdecimal-example/#:~:text=Operations%20using%20Java%20BigDecimal%20class&text=Create%20new%20BigDecimal%20variables%2C%20using,scale()%2C%20augend. 

	}

}
