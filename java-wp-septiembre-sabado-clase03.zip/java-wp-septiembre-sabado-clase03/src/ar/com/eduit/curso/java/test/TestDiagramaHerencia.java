package ar.com.eduit.curso.java.test;

//import ar.com.eduit.curso.java.entities.*; //importa todas las clases del paquete
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;

public class TestDiagramaHerencia {

	public static void main(String[] args) {
		
		/*
		 * Clase Abstracta: puede tener clases hijas, pero no se pueden crear objetos
		 * 
		 * Clase Final (Clases Selladas):	no puede tener clases hijas, pero se pueden crear objetos
		 * 
		 * Métodos abstractos: solo existen en clases abstractas, no tienen cuerpo(Código)
		 */
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"arg$");
		//cuenta1.saldo=3000000;
		//cuenta1.setMoneda("U$S");
		//cuenta1.setSaldo(5000000);
		cuenta1.depositar(50000);
		cuenta1.debitar(20000);
		cuenta1.debitar(30001);
		
		System.out.println(cuenta1.getNro()+" "+cuenta1.getMoneda()+" "+cuenta1.getSaldo());
		System.out.println(cuenta1);
		
		System.out.println("-- dir1 --");
		Direccion dir1=new Direccion("Peru",650,"2","a");
		System.out.println(dir1);
		
		System.out.println("-- dir2 --");
		Direccion dir2=new Direccion("Belgrano",40,null,null,"Morón");
		System.out.println(dir2);

		//Persona persona=new Persona();
		
	}

}
