package ar.com.eduit.curso.java.entities;

//public class CuentaX extends Cuenta{
//
//	public CuentaX(int nro, String moneda) {
//		super(nro, moneda);
//	}
//
//	@Override
//	public void depositar(double monto) {
//		depositar(monto*2);
//	}
//
//}
