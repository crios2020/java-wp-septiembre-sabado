package ar.com.eduit.curso.java.interfaces;

public class FileBinary implements I_File{

	@Override
	public void setText(String text) {
		System.out.println("Escribiendo Archivo de binario!!");
	}

	@Override
	public String getText() {
		return "Leyendo Archivo binario!!";
	}

}
