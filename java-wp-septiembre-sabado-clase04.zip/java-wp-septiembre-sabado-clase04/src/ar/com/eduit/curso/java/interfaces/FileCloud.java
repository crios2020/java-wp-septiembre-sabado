package ar.com.eduit.curso.java.interfaces;

import java.io.Serializable;

public class FileCloud implements I_File, Serializable{

    @Override
    public String getText() {
        return "Leyendo Archivo de Nube!!!";
    }

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo de Nube!!");
    }
    
}
