package ar.com.eduit.curso.java.interfaces;

public interface I_File {
	
	/*
	 * Interfaces en java
	 * - Todos los miémbros de una interface son publicos.
	 * - Una Interface no tiene constructores ni atributos de clases
	 * - Una Interface puede tener constantes o atributos de clases
	 * - Los métodos de una interface son publicos y abstractos
	 * - Una interface puede ser implementada en muchas clases.
	 * - Una clase puede implementar muchas interfaces
	 */
	
	/**
	 * Método para escribir un archivo
	 * @param text texto a escribir
	 */
	void setText(String text);
	/**
	 * Método para leer un archivo
	 * @return texto del archivo
	 */
	String getText();
	
	//Métodos default jdk 8 o sup
	//Un método default tiene cuerpo(Tiene código) 
	default void info() {
		System.out.println("Interface I_File");
	}
	
}
