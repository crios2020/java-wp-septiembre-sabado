package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Auto;
import ar.com.eduit.curso.java.entities.Cliente;
//import ar.com.eduit.curso.java.entities.*; //importa todas las clases del paquete
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestDiagramaHerencia {

	public static void main(String[] args) {
		
		/*
		 * Clase Abstracta: puede tener clases hijas, pero no se pueden crear objetos
		 * 
		 * Clase Final (Clases Selladas):	no puede tener clases hijas, pero se pueden crear objetos
		 * 
		 * Métodos abstractos: solo existen en clases abstractas, no tienen cuerpo(Código)
		 */
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"arg$");
		//cuenta1.saldo=3000000;
		//cuenta1.setMoneda("U$S");
		//cuenta1.setSaldo(5000000);
		cuenta1.depositar(50000);
		cuenta1.debitar(20000);
		cuenta1.debitar(30001);
		
		System.out.println(cuenta1.getNro()+" "+cuenta1.getMoneda()+" "+cuenta1.getSaldo());
		System.out.println(cuenta1);
		
		System.out.println("-- dir1 --");
		Direccion dir1=new Direccion("Peru",650,"2","a");
		System.out.println(dir1);
		
		System.out.println("-- dir2 --");
		Direccion dir2=new Direccion("Belgrano",40,null,null,"Morón");
		System.out.println(dir2);

		//Persona persona=new Persona();
		
		System.out.println("-- vendedor1 --");
		Vendedor vendedor1=new Vendedor("Andrea",26,dir1,1,250000);
		System.out.println(vendedor1);
		vendedor1.saludar();
		
		System.out.println("-- cliente1 --");
		Cliente cliente1=new Cliente("Lautaro",38,dir2,1,cuenta1);
		System.out.println(cliente1);
		cliente1.saludar();
		
		//Polimorfismo - Poliformismo
		Persona p1=new Vendedor("Laura",39,dir2,2,36000);
		Persona p2=new Cliente("Matias", 24, dir1,2,new Cuenta(20,"arg$"));
		
		Object o;
		o=4;
		o="Hola";
		o=dir1;
		
		p1.saludar();
		p2.saludar();
		
		Vendedor v1=(Vendedor)p1;
		Vendedor v2=(p1 instanceof Vendedor)?(Vendedor)p1:null;
		System.out.println(p1 instanceof Vendedor); 	//true
		System.out.println(p2 instanceof Vendedor);    	//false
		System.out.println(p1.getClass().getSimpleName()); 	//Vendedor
		
		System.out.println(p1.getClass());
		System.out.println(p1.getClass().getName());
		System.out.println(p1.getClass().getSimpleName());
		System.out.println(p1.getClass().getSuperclass().getName());
		System.out.println(p1.getClass().getSuperclass().getSuperclass().getName());
		System.out.println(p1.getClass().getSuperclass().getSuperclass().getSuperclass());
		
		String texto="Hola";
		System.out.println(texto.getClass().getName());
		System.out.println(texto.getClass().getSuperclass().getName());
		
		//static
		Auto.acelerar();		//10
		Auto.acelerar();		//20
		
		System.out.println("-- auto1 --");
		Auto auto1=new Auto("Ford","Ka","Rojo");
		auto1.acelerar();		//30
		System.out.println(auto1+" velocidad: "+auto1.getVelocidad());
		
		System.out.println("-- auto2 --");
		Auto auto2=new Auto("Citroen","C4","Negro");
		auto2.acelerar();		//40
		Auto.acelerar();		//50
		System.out.println(auto2+" velocidad: "+auto2.getVelocidad());
		System.out.println(auto1+" velocidad: "+auto1.getVelocidad());
		
		
		
		
		
		//interface
		
	}

}
