package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;

public class TestDiagramaRelaciones {

	public static void main(String[] args) {
		
		//Objetos MOCKS - Objetos Simulados
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"arg$");
		//cuenta1.saldo=3000000;
		//cuenta1.setMoneda("U$S");
		//cuenta1.setSaldo(5000000);
		cuenta1.depositar(50000);
		cuenta1.debitar(20000);
		cuenta1.debitar(30001);
		
		System.out.println(cuenta1.getNro()+" "+cuenta1.getMoneda()+" "+cuenta1.getSaldo());
		System.out.println(cuenta1);
		
		System.out.println("-- clientePersona1 --");
		ClientePersona clientePersona1=new ClientePersona(1,"Ana",25,cuenta1);
		clientePersona1.getCuenta().depositar(50000);
		System.out.println(clientePersona1);
		
		System.out.println("-- Claudia - Marcos --");
		ClientePersona marcos=new ClientePersona(2,"Marcos",40,new Cuenta(2,"args"));
		marcos.getCuenta().depositar(200000);
		ClientePersona claudia=new ClientePersona(3,"Claudia",40,marcos.getCuenta());
		claudia.getCuenta().debitar(150000);
		
		System.out.println(marcos);
		System.out.println(claudia);
		
		System.out.println("-- clientePersona4 --");
		ClientePersona clientePersona4=new ClientePersona(4,"Nicolas",34,3);
		clientePersona4.getCuenta().depositar(40000);
		System.out.println(clientePersona4);
		
		System.out.println("-- clienteEmpresa1");
		ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1,"Todo Limpio SRL","Viel 234");
		clienteEmpresa1.getCuentas().add(new Cuenta(10,"arg$"));		//0
		clienteEmpresa1.getCuentas().add(new Cuenta(11,"Reales"));		//1
		clienteEmpresa1.getCuentas().add(new Cuenta(12,"U$S"));		//2
		clienteEmpresa1.getCuentas().get(0).depositar(500000);
		clienteEmpresa1.getCuentas().get(0).depositar(300000);
		clienteEmpresa1.getCuentas().get(0).debitar(120000);
		clienteEmpresa1.getCuentas().get(1).depositar(35000);
		clienteEmpresa1.getCuentas().get(2).depositar(15000);
		
		System.out.println(clienteEmpresa1);
	
	}

}
