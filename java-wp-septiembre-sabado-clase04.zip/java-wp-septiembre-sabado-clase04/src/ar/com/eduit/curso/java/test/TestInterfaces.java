package ar.com.eduit.curso.java.test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import ar.com.eduit.curso.java.entities.Auto;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.interfaces.FileBinary;
import ar.com.eduit.curso.java.interfaces.FileCloud;
import ar.com.eduit.curso.java.interfaces.FileText;
import ar.com.eduit.curso.java.interfaces.I_File;

public class TestInterfaces {
	public static void main(String[] args) throws Exception{
		
		//Test Interfaces

		I_File file=null;

		//file=new FileText();
		//file=new FileBinary();
		//file=new FileCloud();

		System.out.println("Escriba 'FileText' - 'FileBinary' - 'FileCloud'");
		String in=new Scanner(System.in).nextLine();
		//if(in.equals("FileText")) file=new FileText();
		//if(in.equals("FileBinary")) file=new FileBinary();
		//if(in.equals("FileCloud")) file=new FileCloud();

		//file=(I_File)Class.forName("ar.com.eduit.curso.java.interfaces."+in).newInstance();

		file=(I_File)Class
							.forName("ar.com.eduit.curso.java.interfaces."+in)
							.getConstructor()
							.newInstance();
		

		//App
		file.setText("Holaaa");
		System.out.println(file.getText());
		file.info();


		/*
 		ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(new File("datos.dat")));
		out.writeObject(new Auto("Fiat","Idea","Gris"));
		//out.writeObject(new Cuenta(1,"Args"));

		//out.writeObject(new FileCloud());
		//out.writeObject(new FileText());

		out.close();
		*/
	
		//TODO Exceptions
		

	}
}
