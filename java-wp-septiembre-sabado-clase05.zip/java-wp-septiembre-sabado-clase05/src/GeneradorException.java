public class GeneradorException {

    public static void generar(){
        int[] vector=new int[5];
        vector[10] = 20;
    }

    public static void generar(boolean x){
        if(x) System.out.println(10/0);
    }

    public static void generar(String nro){         // "38v"
        int n=Integer.parseInt(nro);
    }

    public static void generar(String texto, int indice){       //"hola", 20
        //if(texto==null || indice<0 || indice>=texto.length()) return;
        System.out.println(texto.charAt(indice));
    }
}
