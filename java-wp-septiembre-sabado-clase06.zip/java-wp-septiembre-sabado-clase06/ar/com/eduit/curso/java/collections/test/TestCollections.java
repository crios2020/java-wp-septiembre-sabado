package ar.com.eduit.curso.java.collections.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import ar.com.eduit.curso.java.collections.entities.Auto;

public class TestCollections {
    public static void main(String[] args) {
        
        //Vector - Array
        Auto[] autos=new Auto[4];

        autos[0]=new Auto("Ford","Fiesta","Beige");
        autos[1]=new Auto("VW","Gol","Blanco");
        autos[2]=new Auto("Fiat","Idea","Gris");
        autos[3]=new Auto("Citroen","C4","Rojo");

        //Recorrido usando indices
        //for(int a=0; a<autos.length; a++) System.out.println(autos[a]);

        //Recorrido forEach
        for(Auto auto:autos) System.out.println(auto);


        //Interface List
        List lista1;
        
        lista1=new ArrayList();
        //lista1=new LinkedList();
        //lista1=new Vector();

        lista1.add(new Auto("Ford","Fiesta","Negro"));      // 0
        lista1.add(new Auto("Renault","Twingo","Verde"));   // 1
        lista1.add("Hola");                                                   // 2
        lista1.add("Chau");                                                   // 3
        lista1.add(38);                                                       // 4
        lista1.add("Primavera");                                              // 5
        lista1.add("Verano");                                                 // 6
        lista1.add("Otoño");                                                  // 7
        lista1.add("Invierno");                                               // 8

        lista1.add(4,"Java");
        lista1.remove(7);
        lista1.remove("Invierno");

        //copiar autos del vector autos a lista1
        for(Auto auto : autos) lista1.add(auto);

        System.out.println("********************************************************");
        //recorrido con indices
        //for(int a=0; a<lista1.size(); a++) System.out.println(lista1.get(a));

        //Recorrido forEach
        //for(Object o:lista1) System.out.println(o);

        //Recorrido con método .forEach() JDK 8 o sup
        //Lamda Expression - Expresiones Lamda
        //lista1.forEach(o->System.out.println(o));
        //lista1.forEach(o->{
        //    System.out.print("* ");
        //    System.out.println(o);
        //});
        lista1.forEach(System.out::println);

        //Uso de Generics <> jdk 5 o sup
        List<Auto>lista2=new ArrayList();
        lista2.add(new Auto("Chevrolet","Corsa","Rojo"));

        Auto auto1=(Auto)lista1.get(0);
        Auto auto2=lista2.get(0);

        //Copiar autos de lista1 a lista2
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
            //if(o.getClass().getSimpleName().equals("Auto")) lista2.add((Auto)o);
        });

        System.out.println("****************************************************");
        //Recorrido .forEach
        lista2.forEach(System.out::println);

        //Interface Set: Representa una lista dinamica sin indices, sin valores duplicados.
        Set<String> set;

        //Implementación HashSet:   Es la más veloz de todas, .
        //                          no garantiza el orden de los elementos
        //set=new HashSet();

        //Implementación LinkedHashSet: Almacena elementos en una lista enlazada
        //                              por orden de ingreso.
        //set=new LinkedHashSet();

        //Implementación TreeSet:   Almacena elementos en un arbol
        //                          por orden natural(alfabeticamente)
        set=new TreeSet();

        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Jueves");
        set.add("Viernes");
        set.add("Sábado");
        set.add("Domingo");
        set.add("Lunes");
        set.add("Martes");
        set.forEach(System.out::println);

        Set<Auto>setAutos;
        //setAutos=new LinkedHashSet();
        //setAutos=new HashSet();
        setAutos=new TreeSet();

        setAutos.addAll(lista2);
        setAutos.add(new Auto("Citroen","C4","Rojo"));
        setAutos.add(new Auto("VW", "Amarok", "Negro"));
        setAutos.add(new Auto("VW", "Gol", "Azul"));
        setAutos.add(new Auto("VW", "Gol", "Verde"));

        System.out.println("**************************************");
        //setAutos.forEach(System.out::println);
        setAutos.forEach(a->System.out.println(a+" "+a.hashCode()));

        /*
         *  PILAS y COLAS
         * 
         *  LIFO: Last In First Out (Ultimo en Entrar es el Primero en Salir)
         * 
         *  FIFO: First In First Out (Primero en Entrar es el Primero en Salir)
         * 
         * 
         */

        //TODO Codificar Pilas y Colas

        

    }
}
