package ar.com.eduit.curso.java.collections.entities;

public class Empleado {
    private int nroLegajo;
    private String nombre;
    private String cargo;
    
    public Empleado(int nroLegajo, String nombre, String cargo) {
        this.nroLegajo = nroLegajo;
        this.nombre = nombre;
        this.cargo = cargo;
    }

    @Override
    public String toString() {
        return "Empleado [nroLegajo=" + nroLegajo + ", nombre=" + nombre + ", cargo=" + cargo + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + nroLegajo;
        result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
        result = prime * result + ((cargo == null) ? 0 : cargo.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Empleado other = (Empleado) obj;
        if (nroLegajo != other.nroLegajo)
            return false;
        if (nombre == null) {
            if (other.nombre != null)
                return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        if (cargo == null) {
            if (other.cargo != null)
                return false;
        } else if (!cargo.equals(other.cargo))
            return false;
        return true;
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public void setNroLegajo(int nroLegajo) {
        this.nroLegajo = nroLegajo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    
}
