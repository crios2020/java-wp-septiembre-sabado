package ar.com.eduit.curso.java.collections.test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import ar.com.eduit.curso.java.collections.entities.Auto;
import ar.com.eduit.curso.java.collections.entities.Empleado;

public class TestCollections {
    public static void main(String[] args) {
        
        //Vector - Array
        Auto[] autos=new Auto[4];

        autos[0]=new Auto("Ford","Fiesta","Beige");
        autos[1]=new Auto("VW","Gol","Blanco");
        autos[2]=new Auto("Fiat","Idea","Gris");
        autos[3]=new Auto("Citroen","C4","Rojo");

        //Recorrido usando indices
        //for(int a=0; a<autos.length; a++) System.out.println(autos[a]);

        //Recorrido forEach
        for(Auto auto:autos) System.out.println(auto);


        //Interface List
        List lista1;
        
        lista1=new ArrayList();
        //lista1=new LinkedList();
        //lista1=new Vector();

        lista1.add(new Auto("Ford","Fiesta","Negro"));      // 0
        lista1.add(new Auto("Renault","Twingo","Verde"));   // 1
        lista1.add("Hola");                                                   // 2
        lista1.add("Chau");                                                   // 3
        lista1.add(38);                                                       // 4
        lista1.add("Primavera");                                              // 5
        lista1.add("Verano");                                                 // 6
        lista1.add("Otoño");                                                  // 7
        lista1.add("Invierno");                                               // 8

        lista1.add(4,"Java");
        lista1.remove(7);
        lista1.remove("Invierno");

        //copiar autos del vector autos a lista1
        for(Auto auto : autos) lista1.add(auto);

        System.out.println("********************************************************");
        //recorrido con indices
        //for(int a=0; a<lista1.size(); a++) System.out.println(lista1.get(a));

        //Recorrido forEach
        //for(Object o:lista1) System.out.println(o);

        //Recorrido con método .forEach() JDK 8 o sup
        //Lamda Expression - Expresiones Lamda
        //lista1.forEach(o->System.out.println(o));
        //lista1.forEach(o->{
        //    System.out.print("* ");
        //    System.out.println(o);
        //});
        lista1.forEach(System.out::println);

        //Uso de Generics <> jdk 5 o sup
        List<Auto>lista2=new ArrayList();
        lista2.add(new Auto("Chevrolet","Corsa","Rojo"));

        Auto auto1=(Auto)lista1.get(0);
        Auto auto2=lista2.get(0);

        //Copiar autos de lista1 a lista2
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
            //if(o.getClass().getSimpleName().equals("Auto")) lista2.add((Auto)o);
        });

        System.out.println("****************************************************");
        //Recorrido .forEach
        lista2.forEach(System.out::println);

        //Interface Set: Representa una lista dinamica sin indices, sin valores duplicados.
        Set<String> set;

        //Implementación HashSet:   Es la más veloz de todas, .
        //                          no garantiza el orden de los elementos
        //set=new HashSet();

        //Implementación LinkedHashSet: Almacena elementos en una lista enlazada
        //                              por orden de ingreso.
        //set=new LinkedHashSet();

        //Implementación TreeSet:   Almacena elementos en un arbol
        //                          por orden natural(alfabeticamente)
        set=new TreeSet();

        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Jueves");
        set.add("Viernes");
        set.add("Sábado");
        set.add("Domingo");
        set.add("Lunes");
        set.add("Martes");
        set.forEach(System.out::println);

        Set<Auto>setAutos;
        //setAutos=new LinkedHashSet();
        //setAutos=new HashSet();
        setAutos=new TreeSet();

        setAutos.addAll(lista2);
        setAutos.add(new Auto("Citroen","C4","Rojo"));
        setAutos.add(new Auto("VW", "Amarok", "Negro"));
        setAutos.add(new Auto("VW", "Gol", "Azul"));
        setAutos.add(new Auto("VW", "Gol", "Verde"));

        System.out.println("**************************************");
        //setAutos.forEach(System.out::println);
        setAutos.forEach(a->System.out.println(a+" "+a.hashCode()));

        /*
         *  PILAS y COLAS
         * 
         *  LIFO: Last In First Out (Ultimo en Entrar es el Primero en Salir)
         * 
         *  FIFO: First In First Out (Primero en Entrar es el Primero en Salir)
         * 
         * 
         */

        //Clase Stack (Pilas)
        Stack<Auto>pilaAutos=new Stack();
        // .push() apila un elemento en la lista
        pilaAutos.push(new Auto("Fiat","Chronos","Rojo"));
        
        pilaAutos.addAll(setAutos);

        System.out.println("**************************************");
        pilaAutos.forEach(System.out::println);

        System.out.println("Cantidad de Autos: "+pilaAutos.size());

        while(!pilaAutos.isEmpty()){
            // .pop() desapila un elemento de la lista
            System.out.println(pilaAutos.pop());
        }

        System.out.println("Cantidad de Autos: "+pilaAutos.size());


        // Clase ArrayDeque (Cola)
        ArrayDeque<Auto>colaAutos=new ArrayDeque();
        // .offer() Encola un elemento en la lista
        colaAutos.offer(new Auto("Toyota","Corolla","Blanco"));

        colaAutos.addAll(setAutos);
        System.out.println("**************************************");
        colaAutos.forEach(System.out::println);

        System.out.println("Longitud de cola: "+colaAutos.size());
        while(!colaAutos.isEmpty()){
            //Método poll() desencola un elemento
            System.out.println(colaAutos.poll());
        }
        System.out.println("Longitud de cola: "+colaAutos.size());

        //Interface Map: representa un vector asociativo del tipo (llave, valor)
        //  conocido como diccionario o mapa

        Map<String,String>mapaSemana;
        
        //Implementación HashMap La más veloz, es desordenada
        //mapaSemana=new HashMap();

        //Implementación Hashtable Es legacy, es desodenada
        //mapaSemana=new Hashtable();

        //Implementación LinkedHashMap almacena en una lista enlazada por orden de ingreso
        //mapaSemana=new LinkedHashMap();

        //Implementacion TreeMap almacena en un arbol por orden natural
        mapaSemana=new TreeMap();
        
        mapaSemana.put("lu","Lunes");
        mapaSemana.put("ma","Martes");
        mapaSemana.put("mi","Miércoles");
        mapaSemana.put("ju","Jueves");
        mapaSemana.put("vi","Viernes");
        mapaSemana.put("sa","Sábado");
        mapaSemana.put("do","Domingo");
        System.out.println(mapaSemana.get("ju"));
        System.out.println("*********************");
        mapaSemana.forEach((k,v)->System.out.println(k+" "+v));
        System.out.println("*********************");
        mapaSemana.keySet().forEach(k->System.out.println(k+" "+mapaSemana.get(k)));

        System.out.println(System.getProperties());
        System.out.println(System.getProperty("java.specification.vendor"));
        System.out.println(System.getProperty("java.vm.name"));
        System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("java.vm.version"));
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));
        System.out.println(System.getProperty("os.arch"));
        System.out.println(System.getProperty("user.name"));
        System.out.println(System.getProperty("user.language"));
        System.out.println(System.getProperty("user.country"));
        System.out.println(System.getProperty("user.home"));
        System.out.println(
                                Calendar
                                    .getInstance()
                                    .getTimeZone()
                                    .getID()
                                    .replace("/", " ")
                                    .replace("_", " ")
                                );

        
        //Varia en cada SO y JVM
        System.out.println(System.getenv()); 
        System.out.println(System.getenv("LOGNAME"));
        System.out.println(System.getenv("HOME"));
        System.out.println(System.getenv("DESKTOP_SESSION"));
        System.out.println(System.getenv("USER"));

        //Vector disperso
        Map<Integer,String>vectorDisperso=new TreeMap();
        vectorDisperso.put(0, "Ana");
        vectorDisperso.put(-10, "Ana");
        vectorDisperso.put(-30, "Ana");
        vectorDisperso.put(0, "Diego");
        vectorDisperso.put(50, "Jose");
        vectorDisperso.put(23, "Debora");
        vectorDisperso.forEach((k,v)->System.out.println(k+" "+v));

        //Empleados tienen un auto asignado
        Map<Empleado,Auto>mapa=new LinkedHashMap();

        Auto auto10=lista2.get(0);
        Auto auto11=lista2.get(1);
        Auto auto12=lista2.get(2);
        Auto auto13=lista2.get(3);
        Auto auto14=lista2.get(4);

        Empleado empleado1=new Empleado(1,"Ana","Jefe");
        Empleado empleado2=new Empleado(2,"Jose","Gerente");
        Empleado empleado3=new Empleado(3,"Lautaro","Técnico");
        Empleado empleado4=new Empleado(4, "Mariano", "Vendedor");

        mapa.put(empleado1, auto14);
        mapa.put(empleado3, auto10);
        mapa.put(empleado1, auto11);
        mapa.put(empleado4, auto14);
        mapa.put(empleado2, null);

        System.out.println("Empleado 1 tiene "+mapa.get(empleado1));
        System.out.println("**************************************");
        mapa.forEach((e,a)->System.out.println(e+" tiene "+a));


        setAutos.add(new Auto("Peugeot","504","Gris"));
        setAutos.add(new Auto("Fiat","Uno","Rojo"));
        setAutos.add(new Auto("Chevrolet","Meriva","Gris"));
        setAutos.add(new Auto("Chevrolet","Onix","Verde"));

        //Api Stream JDK 8
        System.out.println("*********************************************");
        //select * from autos;
        setAutos.stream().forEach(System.out::println);

        System.out.println("*********************************************");
        //select * from autos where color='Rojo';
        
        for(Auto a: setAutos){
            if(a.getColor().equalsIgnoreCase("Rojo")){
                System.out.println(a);
            }
        }
        
        setAutos
                .stream()
                .filter(a->a.getColor().equalsIgnoreCase("rojo"))
                .forEach((System.out::println));
        
        System.out.println("*********************************************");
        //select * from autos where Marca='Peugeot';
        setAutos
                .stream()
                .filter(a->a.getMarca().equalsIgnoreCase("peugeot"))
                .forEach(System.out::println);


        System.out.println("*********************************************");
        //select * from autos where marca like 'f%';
        setAutos
                .stream()
                .filter(a->a.getMarca().toLowerCase().startsWith("f"))
                .forEach(System.out::println);

        
        System.out.println("*********************************************");
        //select * from autos where marca like 'fi%';
        setAutos
                .stream()
                .filter(a->a.getMarca().toLowerCase().startsWith("fi"))
                .forEach(System.out::println);

        System.out.println("*********************************************");
        //select * from autos where marca like '%t';    
        setAutos
                .stream()
                .filter(a->a.getMarca().toLowerCase().endsWith("t"))
                .forEach(System.out::println);

        System.out.println("*********************************************");
        //select * from autos where marca='Fiat' and color='Rojo';
        setAutos
                .stream()
                .filter(a->a.getMarca().equalsIgnoreCase("fiat")
                        && a.getColor().equalsIgnoreCase("rojo"))
                .forEach(System.out::println);

        setAutos
                .stream()
                .filter(a->a.getMarca().equalsIgnoreCase("fiat"))
                .filter(a->a.getColor().equalsIgnoreCase("rojo"))
                .forEach(System.out::println);
        
        System.out.println("*********************************************");
        //select * from autos where marca='Fiat' or color='Rojo';
        setAutos
            .stream()
            .filter(a->a.getMarca().equalsIgnoreCase("fiat")
                    || a.getColor().equalsIgnoreCase("rojo"))
            .forEach(System.out::println);

        System.out.println("*********************************************");
        //select * from autos where marca like '%t' and color='Rojo';
        setAutos
            .stream()
            .filter(a->a.getMarca().toLowerCase().endsWith("t"))
            .filter(a->a.getColor().equalsIgnoreCase("rojo"))
            .forEach(System.out::println);
        
        System.out.println("*********************************************");
        //select max(marca) from autos;
        System.out.println(
            setAutos
                .stream()
                .max(Comparator.comparing(Auto::getMarca))
                .get()
                .getMarca()
        );

        System.out.println("*********************************************");
        //select min(marca) from autos;
        System.out.println(
            setAutos
                .stream()
                .min(Comparator.comparing(Auto::getMarca))
                .get()
                .getMarca()
        );

        System.out.println("*********************************************");
        //select * from autos where marca=(select min(marca) from autos);
        String marcaMinima=setAutos
                                    .stream()
                                    .min(Comparator.comparing(Auto::getMarca))
                                    .get()
                                    .getMarca();
        setAutos
                .stream()
                .filter(a->a.getMarca().equalsIgnoreCase(marcaMinima))
                .forEach(System.out::println);

        System.out.println("*********************************************");
        //select count(*) from autos;
        System.out.println(
            setAutos
                    .stream()
                    .count()
        );
          
        System.out.println("*********************************************");
        //orden natural
        setAutos
                .stream()
                .sorted()
                .forEach(System.out::println);

        System.out.println("*********************************************");
        //select * from autos order by marca;
        setAutos
            .stream()
            .sorted(Comparator.comparing(Auto::getMarca))
            .forEach(System.out::println);

        System.out.println("*********************************************");
        //select * from autos order by marca desc;
        setAutos
            .stream()
            .sorted(Comparator.comparing(Auto::getMarca).reversed())
            .forEach(System.out::println);
            
        System.out.println("*********************************************");
        //select * from autos order by marca, modelo, color;
        setAutos
            .stream()
            .sorted(
                        Comparator.comparing(Auto::getMarca)
                        .thenComparing(Comparator.comparing(Auto::getModelo))
                        .thenComparing(Comparator.comparing(Auto::getColor)))
            .forEach(System.out::println);
        
        System.out.println("*********************************************");
        //select * from autos order by marca, modelo, color;   
        setAutos
            .stream()
            .sorted(Comparator.comparing(Auto::getColor))
            .sorted(Comparator.comparing(Auto::getModelo))
            .sorted(Comparator.comparing(Auto::getMarca))
            .forEach(System.out::println);

        //TODO revisar SQL alumno
        //TODO https://es.wikipedia.org/wiki/SQL

    }
}
