package ar.com.eduit.curso.java.colegio;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.ResultSet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ar.com.eduit.curso.java.colegio.connectors.Connector;

@SpringBootTest
class ColegioApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void connectorgetConnection() {
		try (ResultSet rs=Connector.getConnection().createStatement().executeQuery("select version()")){
			if(rs.next() && rs.getString(1).length()>0)
				assertEquals(true, true);
			else 
				assertEquals(false, true);
		} catch (Exception e) {
			assertEquals(false, true);
		}
	}

	@Test
	void connectorgetConnectionTime(){
		
	}

}
