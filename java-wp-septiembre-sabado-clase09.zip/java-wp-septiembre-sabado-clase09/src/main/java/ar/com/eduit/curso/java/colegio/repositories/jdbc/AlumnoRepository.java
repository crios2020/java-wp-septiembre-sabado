package ar.com.eduit.curso.java.colegio.repositories.jdbc;

import java.util.List;

import ar.com.eduit.curso.java.colegio.entities.Alumno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_AlumnoRepository;

public class AlumnoRepository implements I_AlumnoRepository {

    @Override
    public void save(Alumno alumno) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void remove(Alumno alumno) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void update(Alumno alumno) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<Alumno> getAll() {
        // TODO Auto-generated method stub
        return null;
    }
    
}
