package ar.com.eduit.curso.java.colegio.test;

import java.util.ArrayList;

import ar.com.eduit.curso.java.colegio.connectors.Connector;
import ar.com.eduit.curso.java.colegio.entities.Alumno;
import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.enums.Dia;
import ar.com.eduit.curso.java.colegio.enums.Turno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.CursoRepository;
import ar.com.eduit.curso.java.colegio.repositories.list.AlumnoRepository;
//import ar.com.eduit.curso.java.colegio.repositories.list.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        //Test de repositorio
        //I_CursoRepository cursoRepository=new CursoRepository(new ArrayList<Curso>());
        I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());
        I_AlumnoRepository alumnoRepository=new AlumnoRepository(new ArrayList<Alumno>());

        cursoRepository.save(new Curso("Java","Rios",Dia.VIERNES,Turno.MAÑANA));
        cursoRepository.save(new Curso("HTML","Gomez",Dia.JUEVES,Turno.TARDE));
        cursoRepository.save(new Curso("PHP","Herrera",Dia.LUNES,Turno.NOCHE));

        Curso curso=new Curso("Python","Rodriguez",Dia.MARTES,Turno.NOCHE);
        cursoRepository.save(curso);
        System.out.println(curso);

        cursoRepository.getAll().forEach(System.out::println);
        System.out.println("*******************************");
        cursoRepository.getLikeProfesor("ri").forEach(System.out::println);
        System.out.println("*******************************");
        cursoRepository.getLikeTitulo("html").forEach(System.out::println);

        /*
        System.out.println("*******************************");
        alumnoRepository.save(new Alumno("Jose","Poreti",34,1));
        alumnoRepository.save(new Alumno("Laura","Salas",26,2));
        alumnoRepository.save(new Alumno("Micaela","Crasy",36,1));

        alumnoRepository.getAll().forEach(System.out::println);
        System.out.println("*******************************");
        alumnoRepository.getLikeApellido("sa").forEach(System.out::println);
        */
    }
}
