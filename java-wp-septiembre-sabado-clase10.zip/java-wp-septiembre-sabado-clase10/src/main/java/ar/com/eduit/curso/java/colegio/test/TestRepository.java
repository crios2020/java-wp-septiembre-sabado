package ar.com.eduit.curso.java.colegio.test;

import java.util.ArrayList;

import ar.com.eduit.curso.java.colegio.connectors.Connector;
import ar.com.eduit.curso.java.colegio.entities.Alumno;
import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.enums.Dia;
import ar.com.eduit.curso.java.colegio.enums.Turno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.CursoRepository;
//import ar.com.eduit.curso.java.colegio.repositories.list.AlumnoRepository;
//import ar.com.eduit.curso.java.colegio.repositories.list.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        //Test de repositorio
        //I_CursoRepository cursoRepository=new CursoRepository(new ArrayList<Curso>());
        I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());
        //I_AlumnoRepository alumnoRepository=new AlumnoRepository(new ArrayList<Alumno>());
        I_AlumnoRepository alumnoRepository=new AlumnoRepository(Connector.getConnection());

        System.out.println("-- Curso Repository --");
        System.out.println("-- cursoRepository.save");
        cursoRepository.save(new Curso("Java","Rios",Dia.VIERNES,Turno.MAÑANA));
        cursoRepository.save(new Curso("HTML","Gomez",Dia.JUEVES,Turno.TARDE));
        cursoRepository.save(new Curso("PHP","Herrera",Dia.LUNES,Turno.NOCHE));

        Curso curso=new Curso("Python","Rodriguez",Dia.MARTES,Turno.NOCHE);
        cursoRepository.save(curso);
        System.out.println(curso);

        System.out.println("-- cursoRepository.remove");
        cursoRepository.remove(cursoRepository.getById(4));

        System.out.println("-- cursoRepository.update");
        curso=cursoRepository.getById(7);
        if(curso!=null && curso.getId()==7){
            curso.setProfesor("Ferrari");
            curso.setDia(Dia.MARTES);
            cursoRepository.update(curso);
        }

        System.out.println("-- cursoRepository.getAll");
        cursoRepository.getAll().forEach(System.out::println);
        System.out.println("*******************************");
        System.out.println("-- cursoRepository.getLikeProfesor");
        cursoRepository.getLikeProfesor("ri").forEach(System.out::println);
        System.out.println("*******************************");
        System.out.println("-- cursoRepository.getLikeTitulo");
        cursoRepository.getLikeTitulo("html").forEach(System.out::println);

        
        System.out.println("*******************************");
        System.out.println("-- Alumno Repository --");
        System.out.println("-- alumnoRepository.save");
        alumnoRepository.save(new Alumno("Jose","Poreti",34,1));
        alumnoRepository.save(new Alumno("Laura","Salas",26,2));
        alumnoRepository.save(new Alumno("Micaela","Crasy",36,1));

        Alumno alumno=new Alumno("Nicolas","Leon",26,7);
        alumnoRepository.save(alumno);
        System.out.println(alumno);

        System.out.println("-- alumnoRepository.remove");
        alumnoRepository.remove(alumnoRepository.getById(11));
        
        System.out.println("-- alumnoRepository.update");
        alumno = alumnoRepository.getById(7);
        if(alumno!=null && alumno.getId()==7){
            alumno.setEdad(35);
            alumno.setIdCurso(2);
            alumnoRepository.update(alumno);
        }

        System.out.println("-- alumnoRepository.getAll");
        alumnoRepository.getAll().forEach(System.out::println);
        System.out.println("*******************************");
        System.out.println("-- alumnoRepository.getLikeApellido");
        alumnoRepository.getLikeApellido("sa").forEach(System.out::println);
        System.out.println("*******************************");
        System.out.println("-- alumnoRepository.getByCurso");
        alumnoRepository.getByCurso(cursoRepository.getById(1)).forEach(System.out::println);;
        
        Curso cursox=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        System.out.println(cursox);
    }
}
