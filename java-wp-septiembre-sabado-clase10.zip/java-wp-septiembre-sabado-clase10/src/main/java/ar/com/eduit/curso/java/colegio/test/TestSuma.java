package ar.com.eduit.curso.java.colegio.test;

import ar.com.eduit.curso.java.colegio.util.Suma;

public class TestSuma {
    public static void main(String[] args) {

        //Test de Objetos Mocks - Objetos Simulados
        Suma sumar=new Suma();
        System.out.println(sumar.sumar(2,2));       //4
        System.out.println(sumar.sumar(4, 0));      //4
    }
}
