package ar.com.eduit.curso.java.colegio.entities;

import org.junit.jupiter.api.Test;

public class AlumnoTest {
    @Test
    void testGetApellido() {

    }

    @Test
    void testGetEdad() {

    }

    @Test
    void testGetId() {

    }

    @Test
    void testGetIdCurso() {

    }

    @Test
    void testGetNombre() {

    }

    @Test
    void testSetApellido() {

    }

    @Test
    void testSetEdad() {

    }

    @Test
    void testSetId() {

    }

    @Test
    void testSetIdCurso() {

    }

    @Test
    void testSetNombre() {

    }

    @Test
    void testToString() {

    }
}
