package ar.com.eduit.curso.java.colegio.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.com.eduit.curso.java.colegio.connectors.Connector;
import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.enums.Dia;
import ar.com.eduit.curso.java.colegio.enums.Turno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;

public class CursoRepositoryTest {

    private I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());

    @Test
    void testSave() {
        Curso curso1=new Curso("HTML","Segovia",Dia.JUEVES,Turno.NOCHE);
        cursoRepository.save(curso1);
        Curso curso2=new Curso("Python","Rodriguez",Dia.MARTES,Turno.TARDE);
        cursoRepository.save(curso2);
        assertEquals(curso1.getId()>0, true);
        assertEquals(curso2.getId(),curso1.getId()+1);
    }

    @Test
    void testGetAll() {
        Curso curso1=new Curso("CSS","Segovia",Dia.MIERCOLES,Turno.NOCHE);
        cursoRepository.save(curso1);
        int size1=cursoRepository.getAll().size();
        Curso curso2=new Curso("C++","Rodriguez",Dia.LUNES,Turno.MAÑANA);
        cursoRepository.save(curso2);
        int size2=cursoRepository.getAll().size();
        assertEquals(size1>0, true);
        assertEquals(size2, size1+1);

        Curso curso3=cursoRepository.getById(curso2.getId());
        assertEquals(curso2.toString(), curso3.toString());
        assertEquals(curso2.getId(), curso3.getId());
        assertEquals(curso2.getTitulo(), curso3.getTitulo());
        assertEquals(curso2.getProfesor(), curso3.getProfesor());
        assertEquals(curso2.getDia(), curso3.getDia());
        assertEquals(curso2.getTurno(), curso3.getTurno());
    }

    @Test
    void testRemove() {
        int cantidad1=cursoRepository.getAll().size();
        Curso curso1=new Curso("java","Lorenzo",Dia.MIERCOLES,Turno.NOCHE);
        cursoRepository.save(curso1);
        Curso curso2=new Curso(".NET","Rodriguez",Dia.LUNES,Turno.MAÑANA);
        cursoRepository.save(curso2);
        int cantidad2=cursoRepository.getAll().size();
        int idCurso1=curso1.getId();
        int idCurso2=curso2.getId();
        cursoRepository.remove(curso1);
        cursoRepository.remove(curso2);
        int cantidad3=cursoRepository.getAll().size();
        assertEquals(cantidad1+2, cantidad2);
        assertEquals(cantidad2-2, cantidad3);
        assertEquals(idCurso1>0, true);
        assertEquals(idCurso2, idCurso1+1);
        curso1=cursoRepository.getById(idCurso1);
        curso2=cursoRepository.getById(idCurso2);
        if(curso1==null){
            assertEquals(true, true);
        }else{
            assertEquals(curso1.getId(), 0);
        }

        if(curso2==null){
            assertEquals(true, true);
        }else{
            assertEquals(curso2.getId(), 0);
        }

    }


    @Test
    void testUpdate() {
        Curso curso1 = cursoRepository.getAll().get(cursoRepository.getAll().size()-1);
        curso1.setTitulo("ooo1");
        curso1.setProfesor("ooo2");
        curso1.setDia(Dia.VIERNES);
        curso1.setTurno(Turno.NOCHE);
        cursoRepository.update(curso1);

        Curso curso2 = cursoRepository.getAll().get(cursoRepository.getAll().size()-1);

        assertEquals(curso1.getId(), curso2.getId());
        assertEquals(curso1.getTitulo(), curso2.getTitulo());
        assertEquals(curso1.getProfesor(), curso2.getProfesor());
        assertEquals(curso1.getDia(), curso2.getDia());
        assertEquals(curso1.getTurno(), curso2.getTurno());
        

    }
}
