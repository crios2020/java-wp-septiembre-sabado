package ar.com.eduit.curso.java.colegio.entities;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.com.eduit.curso.java.colegio.enums.Dia;
import ar.com.eduit.curso.java.colegio.enums.Turno;

public class CursoTest {

    @Test
    void testGetDia() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        assertEquals(curso.getDia(), Dia.LUNES);
    }

    @Test
    void testGetId() {
        Curso curso=new Curso(100,"ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        assertEquals(curso.getId(), 100);
    }

    @Test
    void testGetProfesor() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        assertEquals(curso.getProfesor(), "ooo2");
    }

    @Test
    void testGetTitulo() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        assertEquals(curso.getTitulo(), "ooo1");
    }

    @Test
    void testGetTurno() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        assertEquals(curso.getTurno(), Turno.NOCHE);
    }

    @Test
    void testSetDia() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        curso.setDia(Dia.MARTES);
        assertEquals(curso.getDia(), Dia.MARTES);
    }

    @Test
    void testSetId() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        curso.setId(200);
        assertEquals(curso.getId(), 200);
    }

    @Test
    void testSetProfesor() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        curso.setProfesor("xxx2");
        assertEquals(curso.getProfesor(), "xxx2");
    }

    @Test
    void testSetTitulo() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        curso.setTitulo("xxx1");
        assertEquals(curso.getTitulo(), "xxx1");
    }

    @Test
    void testSetTurno() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        curso.setTurno(Turno.TARDE);
        assertEquals(curso.getTurno(), Turno.TARDE);
    }

    @Test
    void testToString() {
        Curso curso=new Curso("ooo1","ooo2",Dia.LUNES,Turno.NOCHE);
        assertEquals(curso.toString(), "Curso [id=0, titulo=ooo1, profesor=ooo2, dia=LUNES, turno=NOCHE]");
    }
}
