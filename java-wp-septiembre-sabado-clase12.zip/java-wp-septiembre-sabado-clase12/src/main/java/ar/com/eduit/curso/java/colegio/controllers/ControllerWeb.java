package ar.com.eduit.curso.java.colegio.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.com.eduit.curso.java.colegio.connectors.Connector;
import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.enums.Dia;
import ar.com.eduit.curso.java.colegio.enums.Turno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.CursoRepository;
import ar.com.eduit.curso.java.colegio.util.Fecha;
import ar.com.eduit.curso.java.colegio.util.SistemaOperativo;
import ar.com.eduit.curso.java.colegio.util.Ubicacion;
import ar.com.eduit.curso.java.colegio.util.Usuario;
import ar.com.eduit.curso.java.colegio.util.VersionJava;

@Controller
public class ControllerWeb {

    private I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());
    private I_AlumnoRepository alumnoRepository=new AlumnoRepository(Connector.getConnection());
    private String mensajeCursos="Ingrese un nuevo Curso!";
    
    @GetMapping("/")
    public String index(){
        return "index";
    }

    @GetMapping("/cursos")
    public String cursos(
                Model model, 
                @RequestParam(name="buscarTitulo", required = false, defaultValue = "")String buscarTitulo){
        model.addAttribute("dias", List.of(Dia.values()));
        model.addAttribute("turnos", List.of(Turno.values()));
        model.addAttribute("curso", new Curso());
        model.addAttribute("mensajeCursos", mensajeCursos);
        //model.addAttribute("all", cursoRepository.getAll());
        model.addAttribute("likeTitulo", cursoRepository.getLikeTitulo(buscarTitulo));
        return "cursos";
    }

    @PostMapping("/saveCurso")
    public String saveCurso(@ModelAttribute Curso curso){

        //mensajeCursos="Se ejecuto el método saveCurso "+curso.toString();
        //System.out.println("********************************************");
        //System.out.println(curso.toString());
        //System.out.println("********************************************");

        cursoRepository.save(curso);
        if(curso.getId()>0){
            mensajeCursos="Se guardo el curso con id: "+curso.getId();
        }else{
            mensajeCursos="No se pudo guardar el curso!";
        }

        return "redirect:cursos";
    }

    @GetMapping("/alumnos")
    public String alumnos(Model model){
        model.addAttribute("cursos",cursoRepository.getAll());
        return "alumnos";
    }

    @GetMapping("/config")
    public String config(Model model){
        model.addAttribute("os", new SistemaOperativo().getSistemaOperativo());
        model.addAttribute("java", new VersionJava().getVersionJava());
        model.addAttribute("ubicacion", new Ubicacion().getUbicacion());
        model.addAttribute("fecha", new Fecha().getFecha());
        model.addAttribute("usuario", new Usuario().getUsuario());
        return "config";
    }

    @GetMapping("/test")
    public String test(){
        return "test";
    }

}
