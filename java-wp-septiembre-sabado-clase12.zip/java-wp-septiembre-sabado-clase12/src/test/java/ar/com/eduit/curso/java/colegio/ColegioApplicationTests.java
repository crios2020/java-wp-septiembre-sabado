package ar.com.eduit.curso.java.colegio;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.ResultSet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ar.com.eduit.curso.java.colegio.connectors.Connector;

@SpringBootTest
class ColegioApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void test1(){
		assertEquals(true, true);
		//assertEquals(true, false);
	}

	@Test
	void test2(){
		assertEquals(2+2, 4);		//testOK
		//assertEquals(2+2, 5);		//testError Test mal realizado
	}

	@Test
	void connectorgetConnection() {
		try (ResultSet rs=Connector.getConnection().createStatement().executeQuery("select version()")){
			if(rs.next() && rs.getString(1).length()>0)
				assertEquals(true, true);
			else 
				assertEquals(false, true);
		} catch (Exception e) {
			assertEquals(false, true);
		}
	}

	@Test
	void connectorgetConnectionTime(){
		
	}

}
