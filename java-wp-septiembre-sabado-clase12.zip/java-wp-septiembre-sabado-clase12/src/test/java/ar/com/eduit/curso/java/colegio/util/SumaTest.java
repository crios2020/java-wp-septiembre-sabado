package ar.com.eduit.curso.java.colegio.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class SumaTest {
    @Test
    void testSumar() {
        Suma suma=new Suma();
        assertEquals(suma.sumar(2, 2), 4);
        assertEquals(suma.sumar(2, 0), 2);
        assertEquals(suma.sumar(2, -2), 0);
        assertEquals(suma.sumar(-2, -2), -4);
    }
}
