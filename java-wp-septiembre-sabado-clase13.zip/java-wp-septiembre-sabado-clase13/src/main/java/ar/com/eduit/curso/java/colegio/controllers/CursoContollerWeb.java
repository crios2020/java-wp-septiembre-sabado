package ar.com.eduit.curso.java.colegio.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.com.eduit.curso.java.colegio.connectors.Connector;
import ar.com.eduit.curso.java.colegio.entities.Curso;
import ar.com.eduit.curso.java.colegio.enums.Dia;
import ar.com.eduit.curso.java.colegio.enums.Turno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.CursoRepository;

@Controller
public class CursoContollerWeb {
    
    private I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());
    private String mensajeCursos="Ingrese un nuevo Curso!";

    @GetMapping("/cursos")
    public String cursos(
                Model model, 
                @RequestParam(name="buscarTitulo", required = false, defaultValue = "")String buscarTitulo){
        model.addAttribute("dias", List.of(Dia.values()));
        model.addAttribute("turnos", List.of(Turno.values()));
        model.addAttribute("curso", new Curso());
        model.addAttribute("mensajeCursos", mensajeCursos);
        //model.addAttribute("all", cursoRepository.getAll());
        model.addAttribute("likeTitulo", cursoRepository.getLikeTitulo(buscarTitulo));
        return "cursos";
    }

    @PostMapping("/saveCurso")
    public String saveCurso(@ModelAttribute Curso curso){

        cursoRepository.save(curso);
        if(curso.getId()>0){
            mensajeCursos="Se guardo el curso con id: "+curso.getId();
        }else{
            mensajeCursos="No se pudo guardar el curso!";
        }

        return "redirect:cursos";
    }
}
