package ar.com.eduit.curso.java.colegio.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexControllerWeb {
    @GetMapping("/")
    public String index(){
        return "index";
    }
}
