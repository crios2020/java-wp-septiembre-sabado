package ar.com.eduit.curso.java.colegio.test;

public class TestHolaMundo {
    public static void main(String[] args) {
        System.out.println("Hola Mundo!!!");
        System.out.println("Versión de java "+System.getProperty("java.version"));
    }
}
