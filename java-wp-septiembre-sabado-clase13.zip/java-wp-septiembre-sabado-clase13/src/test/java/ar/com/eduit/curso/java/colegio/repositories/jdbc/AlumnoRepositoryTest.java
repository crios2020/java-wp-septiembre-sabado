package ar.com.eduit.curso.java.colegio.repositories.jdbc;

import org.junit.jupiter.api.Test;

public class AlumnoRepositoryTest {
    @Test
    void testGetAll() {

    }

    @Test
    void testRemove() {

    }

    @Test
    void testSave() {

    }

    @Test
    void testUpdate() {

    }
}
