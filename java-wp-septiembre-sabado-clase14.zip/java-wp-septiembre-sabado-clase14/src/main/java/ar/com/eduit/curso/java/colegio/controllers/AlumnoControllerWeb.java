package ar.com.eduit.curso.java.colegio.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.com.eduit.curso.java.colegio.connectors.Connector;
import ar.com.eduit.curso.java.colegio.entities.Alumno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.colegio.repositories.jdbc.CursoRepository;

@Controller
public class AlumnoControllerWeb {
    
    private I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());
    private I_AlumnoRepository alumnoRepository=new AlumnoRepository(Connector.getConnection());
    private String mensajeAlumnos="Ingrese un nuevo Alumno!";
    
    @GetMapping("/alumnos")
    public String alumnos(Model model, @RequestParam(name = "buscarApellido", required = false, defaultValue = "")String buscarApellido){
        model.addAttribute("cursos",cursoRepository.getAll());
        Alumno alumno=new Alumno();
        alumno.setEdad(18);
        model.addAttribute("alumno", alumno);
        model.addAttribute("mensajeAlumnos", mensajeAlumnos);
        //model.addAttribute("all", alumnoRepository.getAll());
        model.addAttribute("likeApellido",alumnoRepository.getLikeApellido(buscarApellido));
        return "alumnos";
    }

    @PostMapping("/saveAlumno")
    public String saveAlumno(@ModelAttribute Alumno alumno){
        alumnoRepository.save(alumno);
        if(alumno.getId()>0){
            mensajeAlumnos="Se guardo un alumno id: "+alumno.getId();
        }else{
            mensajeAlumnos="No se pudo guardar el alumno!";
        }
        return "redirect:alumnos";
    }
}
