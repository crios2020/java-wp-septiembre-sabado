package ar.com.eduit.curso.java.colegio.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.com.eduit.curso.java.colegio.utils.sistema.Fecha;
import ar.com.eduit.curso.java.colegio.utils.sistema.SistemaOperativo;
import ar.com.eduit.curso.java.colegio.utils.sistema.Ubicacion;
import ar.com.eduit.curso.java.colegio.utils.sistema.Usuario;
import ar.com.eduit.curso.java.colegio.utils.sistema.VersionJava;

@Controller
public class ConfigControllerWeb {

    @GetMapping("/config")
    public String config(Model model){
        model.addAttribute("os", new SistemaOperativo().getSistemaOperativo());
        model.addAttribute("java", new VersionJava().getVersionJava());
        model.addAttribute("ubicacion", new Ubicacion().getUbicacion());
        model.addAttribute("fecha", new Fecha().getFecha());
        model.addAttribute("usuario", new Usuario().getUsuario());
        return "config";
    }

}
