package ar.com.eduit.curso.java.colegio.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.com.eduit.curso.java.colegio.entities.Curso;

public interface I_CursoRepository {
    void save(Curso curso);
    void remove(Curso curso);
    void update(Curso curso);
    default Curso getById(int id){  //select * from cursos where id=id;
        return getAll()
                    .stream()
                    .filter(curso->curso.getId()==id)
                    .findAny()
                    .orElse(new Curso());
    }
    List<Curso>getAll();        //select * from cursos where fecha>=1/1/202;
    default List<Curso>getLikeTitulo(String titulo){    //select * from cursos where titulo like '%titulo%';
        if(titulo==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(curso->curso.getTitulo()!=null)
                    .filter(curso->curso.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
                    .toList();          //JDK 16 o sup  - Inumutable List
    }
    default List<Curso>getLikeProfesor(String profesor){    //select * from cursos where profesor like '%profesor%';
        if(profesor==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(curso->curso.getProfesor()!=null)
                    .filter(curso->curso.getProfesor().toLowerCase().contains(profesor.toLowerCase()))
                    .collect(Collectors.toList());          //JDK 15 o inf  - Mutable List
    }
    default List<Curso>getLikeTituloProfesor(String titulo, String profesor){
        if(titulo==null || profesor==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(curso->curso.getTitulo()!=null)
                    .filter(curso->curso.getProfesor()!=null)
                    .filter(curso->curso.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
                    .filter(curso->curso.getProfesor().toLowerCase().contains(profesor.toLowerCase()))
                    .toList();         
    }
}
