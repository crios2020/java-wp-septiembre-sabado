package ar.com.eduit.curso.java.colegio.repositories.list;

import java.util.List;

import ar.com.eduit.curso.java.colegio.entities.Alumno;
import ar.com.eduit.curso.java.colegio.repositories.interfaces.I_AlumnoRepository;

public class AlumnoRepository implements I_AlumnoRepository{
    public List<Alumno>list;
    public AlumnoRepository(List<Alumno>list){
        this.list=list;
    }

    @Override
    public void save(Alumno alumno) {
        list.add(alumno);        
    }
    @Override
    public void remove(Alumno alumno) {
        list.remove(alumno);
    }
    @Override
    public void update(Alumno alumno) {
        // Método no implementado
        
    }
    @Override
    public List<Alumno> getAll() {
        return list;
    }
}
