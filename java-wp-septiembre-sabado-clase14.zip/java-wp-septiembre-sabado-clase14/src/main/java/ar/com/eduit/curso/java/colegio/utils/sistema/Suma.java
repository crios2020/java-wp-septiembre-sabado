package ar.com.eduit.curso.java.colegio.utils.sistema;

public class Suma {
    public int sumar(int nro1, int nro2){
        return nro1+nro2;
    }
}
